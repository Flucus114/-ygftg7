package com.classselector;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BannerItem;
import net.minecraft.world.item.ItemStack;

/** Menu do Warden domado: slot de capacete e slot de estandarte (nas costas). */
public class WardenMenu extends AbstractContainerMenu {
    private static final EquipmentSlot[] GEAR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST};

    /** Id do botão do menu que alterna entre sentado e em pé. */
    public static final int BTN_TOGGLE_SIT = 0;

    public final Warden warden; // pode ser null no cliente se a entidade não for encontrada
    /** 1 = sentado, 0 = em pé. Sincronizado servidor -> cliente. */
    private final DataSlot sitSlot = DataSlot.standalone();

    public WardenMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, resolve(inv.player, buf.readVarInt()));
    }

    private static Warden resolve(Player p, int entityId) {
        Entity e = p.level().getEntity(entityId);
        return e instanceof Warden w ? w : null;
    }

    public WardenMenu(int id, Inventory inv, Warden w) {
        super(ModMenus.WARDEN_GEAR.get(), id);
        this.warden = w;
        addDataSlot(sitSlot);
        if (w != null && !w.level().isClientSide) sitSlot.set(TamedWarden.isSitting(w) ? 1 : 0);
        Container gear = w == null ? new SimpleContainer(2) : new GearContainer(w);

        addSlot(new Slot(gear, 0, 98, 24) {
            @Override public boolean mayPlace(ItemStack s) {
                return w != null && s.canEquip(EquipmentSlot.HEAD, w);
            }
            @Override public int getMaxStackSize() { return 1; }
        });
        addSlot(new Slot(gear, 1, 98, 48) {
            @Override public boolean mayPlace(ItemStack s) {
                return s.getItem() instanceof BannerItem;
            }
            @Override public int getMaxStackSize() { return 1; }
        });

        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 84 + r * 18));
        for (int c = 0; c < 9; c++)
            addSlot(new Slot(inv, c, 8 + c * 18, 142));
    }

    public boolean isSitting() { return sitSlot.get() == 1; }

    @Override
    public void broadcastChanges() {
        if (warden != null && !warden.level().isClientSide) sitSlot.set(TamedWarden.isSitting(warden) ? 1 : 0);
        super.broadcastChanges();
    }

    /** Chamado no servidor quando o jogador clica no botão do menu. */
    @Override
    public boolean clickMenuButton(Player p, int id) {
        if (id != BTN_TOGGLE_SIT || warden == null || !warden.isAlive()) return false;
        if (!TamedWarden.isTamed(warden) || !p.getUUID().equals(TamedWarden.ownerId(warden))) return false;
        boolean sit = !TamedWarden.isSitting(warden);
        TamedWarden.setSitting(warden, sit);
        sitSlot.set(sit ? 1 : 0);
        p.displayClientMessage(Component.literal(sit ? "O Warden agora está sentado." : "O Warden agora está em pé."), true);
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player p, int idx) {
        ItemStack ret = ItemStack.EMPTY;
        Slot slot = slots.get(idx);
        if (slot != null && slot.hasItem()) {
            ItemStack st = slot.getItem();
            ret = st.copy();
            if (idx < 2) {
                if (!moveItemStackTo(st, 2, slots.size(), true)) return ItemStack.EMPTY;
            } else if (slots.get(0).mayPlace(st) && !slots.get(0).hasItem()) {
                if (!moveItemStackTo(st, 0, 1, false)) return ItemStack.EMPTY;
            } else if (slots.get(1).mayPlace(st) && !slots.get(1).hasItem()) {
                if (!moveItemStackTo(st, 1, 2, false)) return ItemStack.EMPTY;
            } else {
                return ItemStack.EMPTY;
            }
            if (st.isEmpty()) slot.setByPlayer(ItemStack.EMPTY); else slot.setChanged();
        }
        return ret;
    }

    @Override
    public boolean stillValid(Player p) {
        return warden != null && warden.isAlive() && p.distanceToSqr(warden) < 100.0;
    }

    /** Container que lê/escreve direto nos slots de equipamento do Warden (sincronizados com o cliente). */
    private static class GearContainer implements Container {
        private final Warden w;
        GearContainer(Warden w) { this.w = w; }

        @Override public int getContainerSize() { return 2; }
        @Override public boolean isEmpty() { return getItem(0).isEmpty() && getItem(1).isEmpty(); }
        @Override public ItemStack getItem(int i) { return w.getItemBySlot(GEAR[i]); }

        @Override public ItemStack removeItem(int i, int n) {
            ItemStack s = getItem(i);
            if (s.isEmpty() || n <= 0) return ItemStack.EMPTY;
            ItemStack out = s.split(n);
            if (s.isEmpty()) w.setItemSlot(GEAR[i], ItemStack.EMPTY);
            return out;
        }

        @Override public ItemStack removeItemNoUpdate(int i) {
            ItemStack s = getItem(i);
            w.setItemSlot(GEAR[i], ItemStack.EMPTY);
            return s;
        }

        @Override public void setItem(int i, ItemStack st) {
            w.setItemSlot(GEAR[i], st);
            w.setDropChance(GEAR[i], 2.0F); // sempre dropa se o Warden morrer
        }

        @Override public void setChanged() {}
        @Override public boolean stillValid(Player p) { return w.isAlive() && p.distanceToSqr(w) < 100.0; }
        @Override public void clearContent() {
            w.setItemSlot(GEAR[0], ItemStack.EMPTY);
            w.setItemSlot(GEAR[1], ItemStack.EMPTY);
        }
    }
}
