package com.classselector;

import com.mojang.logging.LogUtils;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

import java.lang.reflect.Method;

/**
 * Aumenta o dano das invocações do Iron's Spells 'n Spellbooks quando o invocador segura o Cajado Necromante.
 * O mod não depende do Iron's em tempo de compilação: a interface MagicSummon é lida por reflexão.
 * Se ela não for encontrada, avisa uma vez no log e o cajado simplesmente não dá bônus (sem crash).
 */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public final class NecroEvents {
    private static final Logger LOG = LogUtils.getLogger();

    private static boolean init = false;
    private static Class<?> summonClass;
    private static Method getSummoner;

    private NecroEvents() { }

    private static synchronized void init() {
        if (init) return;
        init = true;
        try {
            summonClass = Class.forName("io.redspace.ironsspellbooks.entity.mobs.MagicSummon");
            getSummoner = summonClass.getMethod("getSummoner");
        } catch (Throwable t) {
            summonClass = null;
            getSummoner = null;
            LOG.warn("[classselector] MagicSummon do Iron's Spellbooks nao encontrado; o Cajado Necromante nao dara bonus.");
        }
    }

    /** Dono da invocação (ou null se {@code e} não for uma invocação do Iron's). */
    private static LivingEntity summonerOf(Entity e) {
        init();
        if (summonClass == null || getSummoner == null || !summonClass.isInstance(e)) return null;
        try {
            return getSummoner.invoke(e) instanceof LivingEntity l ? l : null;
        } catch (Throwable t) {
            return null;
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        Entity src = e.getSource().getEntity(); // para flechas/projéteis, é o dono (a invocação)
        if (!(src instanceof LivingEntity attacker) || attacker.level().isClientSide) return;
        LivingEntity owner = summonerOf(attacker);
        if (owner == null || owner == e.getEntity()) return;
        if (!(owner.getMainHandItem().getItem() instanceof NecroStaffItem)
                && !(owner.getOffhandItem().getItem() instanceof NecroStaffItem)) return;

        e.setAmount(e.getAmount() * NecroStaffItem.SUMMON_DAMAGE_MULT);
        if (e.getEntity().level() instanceof ServerLevel sl) {
            LivingEntity t = e.getEntity();
            sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, t.getX(), t.getY(0.6D), t.getZ(), 6, 0.3, 0.4, 0.3, 0.02);
        }
    }
}
