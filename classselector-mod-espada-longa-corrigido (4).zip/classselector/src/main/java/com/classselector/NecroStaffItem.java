package com.classselector;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Cajado Necromante: complemento do Iron's Spells 'n Spellbooks.
 * Enquanto estiver em uma das mãos, as criaturas invocadas pelo jogador (Iron's) causam mais dano
 * (ver NecroEvents). Sem receita e sem loot: /give @s classselector:necro_staff
 * Visual: modelo 3D de cubos em models/item/necro_staff.json (gerado por gen_staff.py).
 */
public class NecroStaffItem extends Item {
    /** Multiplicador de dano das invocações (1.5 = +50%). */
    public static final float SUMMON_DAMAGE_MULT = 1.5F;

    private final Multimap<Attribute, AttributeModifier> mods;

    public NecroStaffItem() {
        super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
        ImmutableMultimap.Builder<Attribute, AttributeModifier> b = ImmutableMultimap.builder();
        b.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", 2.0D, AttributeModifier.Operation.ADDITION));
        b.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", -2.8D, AttributeModifier.Operation.ADDITION));
        this.mods = b.build();
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        return slot == EquipmentSlot.MAINHAND ? this.mods : super.getDefaultAttributeModifiers(slot);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("item.classselector.necro_staff.lore1").withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("item.classselector.necro_staff.lore2").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tips.add(Component.empty());
        tips.add(Component.translatable("item.classselector.necro_staff.bonus",
                Math.round((SUMMON_DAMAGE_MULT - 1.0F) * 100.0F)).withStyle(ChatFormatting.DARK_PURPLE));
        super.appendHoverText(stack, level, tips, flag);
    }
}
