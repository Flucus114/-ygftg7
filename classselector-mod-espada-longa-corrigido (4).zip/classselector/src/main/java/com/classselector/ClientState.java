package com.classselector;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Cópia no cliente dos dados sincronizados (sem imports de classes só-cliente). */
public class ClientState {
    public static final List<ClassDef> classes = new ArrayList<>();
    public static final Map<String, RaceDef> races = new LinkedHashMap<>();
    public static boolean op = false;
    public static String myRace = "";
}
