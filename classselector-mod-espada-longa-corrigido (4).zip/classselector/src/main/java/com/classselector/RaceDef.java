package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Raça: bônus BASE (atributos permanentes), nunca efeitos de poção. */
public class RaceDef {
    public String id = "", name = "", description = "", icon = "minecraft:emerald";
    public double mana;       // + mana máxima (Iron's Spells), valor fixo
    public double armor;      // + defesa (pontos de armadura)
    public double damage;     // + dano corpo a corpo, valor fixo
    public double speedPct;   // % velocidade de movimento
    public double miningPct;  // % velocidade de mineração
    public int enchant;       // + níveis de poder na mesa de encantamento

    public ItemStack iconStack() {
        ResourceLocation rl = ResourceLocation.tryParse(icon);
        Item it = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
        return new ItemStack(it == null || it == Items.AIR ? Items.BARRIER : it);
    }

    public static String fmt(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(Math.round(d * 100.0) / 100.0);
    }

    private static String sgn(double d) { return (d >= 0 ? "+" : "") + fmt(d); }

    /** Linhas de bônus para mostrar na tela. */
    public List<String> lines() {
        List<String> l = new ArrayList<>();
        if (mana != 0) l.add(sgn(mana) + " de mana máxima");
        if (armor != 0) l.add(sgn(armor) + " de defesa");
        if (damage != 0) l.add(sgn(damage) + " de dano");
        if (speedPct != 0) l.add(sgn(speedPct) + "% de velocidade");
        if (miningPct != 0) l.add(sgn(miningPct) + "% de vel. de mineração");
        if (enchant != 0) l.add(sgn(enchant) + " de poder de encantamento");
        return l;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("id", id);
        t.putString("name", name);
        t.putString("description", description);
        t.putString("icon", icon);
        t.putDouble("mana", mana);
        t.putDouble("armor", armor);
        t.putDouble("damage", damage);
        t.putDouble("speedPct", speedPct);
        t.putDouble("miningPct", miningPct);
        t.putInt("enchant", enchant);
        return t;
    }

    public static RaceDef load(CompoundTag t) {
        RaceDef r = new RaceDef();
        r.id = t.getString("id");
        r.name = t.getString("name");
        r.description = t.getString("description");
        r.icon = t.getString("icon");
        r.mana = t.getDouble("mana");
        r.armor = t.getDouble("armor");
        r.damage = t.getDouble("damage");
        r.speedPct = t.getDouble("speedPct");
        r.miningPct = t.getDouble("miningPct");
        r.enchant = t.getInt("enchant");
        return r;
    }

    private static double clamp(double v, double lo, double hi) { return Math.max(lo, Math.min(hi, v)); }

    /** Limites de segurança aplicados no servidor. */
    public void clampValues() {
        mana = clamp(mana, -1000, 5000);
        armor = clamp(armor, -20, 30);
        damage = clamp(damage, -20, 100);
        speedPct = clamp(speedPct, -90, 300);
        miningPct = clamp(miningPct, -90, 1000);
        enchant = (int) clamp(enchant, -30, 30);
    }
}
