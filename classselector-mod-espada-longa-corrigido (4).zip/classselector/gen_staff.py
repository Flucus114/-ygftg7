#!/usr/bin/env python3
"""Gera o Cajado Necromante: textura 32x32 e modelo 3D (cubos) em JSON.
Uso: python3 gen_staff.py   (escreve em src/main/resources/assets/classselector/...)
O cajado é montado ao longo do eixo Y (y = -16 .. 32), centrado em x=8, z=8."""
import json, random, os
from PIL import Image

ROOT = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ROOT, "src/main/resources/assets/classselector")
random.seed(7)

# ---------- textura: 4x4 tiles de 8x8 ----------
PAL = {
    "black": (20, 10, 32), "dark": (42, 18, 69), "mid": (74, 42, 120),
    "glow": (143, 60, 255), "glow2": (196, 130, 255), "hot": (235, 200, 255),
    "bone": (169, 143, 160), "bone_d": (110, 86, 104), "chain": (88, 82, 100),
}
TILES = {"wrap": (0, 0), "bone": (1, 0), "glow": (2, 0), "rune": (3, 0),
         "skull": (0, 1), "chain": (1, 1), "crystal": (2, 1), "cloth": (3, 1)}

def px(img, t, x, y, c):
    img.putpixel((TILES[t][0] * 8 + x, TILES[t][1] * 8 + y), PAL[c] + (255,))

img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
for y in range(8):
    for x in range(8):
        px(img, "wrap", x, y, random.choice(["dark", "dark", "black", "mid"]) if (x + y) % 4 else "black")
        px(img, "bone", x, y, random.choice(["bone", "bone", "bone_d"]))
        r = random.random()
        px(img, "glow", x, y, "glow" if r < .5 else ("glow2" if r < .85 else "hot"))
        px(img, "rune", x, y, "dark" if random.random() < .8 else "black")
        px(img, "chain", x, y, "chain" if (x + y) % 2 else "black")
        px(img, "crystal", x, y, random.choice(["glow", "glow2", "glow2", "hot"]))
        px(img, "cloth", x, y, random.choice(["black", "dark", "dark", "mid"]))
        px(img, "skull", x, y, random.choice(["bone", "bone", "bone_d"]))
for x in (1, 6):                       # runas brilhantes
    for y in (1, 2, 4, 5, 6):
        px(img, "rune", x, y, "glow2")
px(img, "rune", 3, 3, "glow"); px(img, "rune", 4, 3, "glow")
for (x, y) in [(1, 2), (2, 2), (5, 2), (6, 2), (1, 3), (2, 3), (5, 3), (6, 3), (3, 5), (4, 5)]:
    px(img, "skull", x, y, "black")    # olhos e nariz
for x in range(1, 7):
    px(img, "skull", x, 7, "bone_d")   # mandíbula
os.makedirs(os.path.join(RES, "textures/item"), exist_ok=True)
img.save(os.path.join(RES, "textures/item/necro_staff.png"))

# ---------- modelo ----------
def uv(t):
    x, y = TILES[t]
    return [x * 8, y * 8, x * 8 + 8, y * 8 + 8]

els = []
def cube(name, a, b, tile, front=None):
    faces = {}
    for f in ("north", "east", "south", "west", "up", "down"):
        t = front if (front and f == "north") else tile
        faces[f] = {"uv": uv(t), "texture": "#0"}
    els.append({"name": name, "from": a, "to": b, "faces": faces})

# haste (eixo central)
cube("haste_baixo", [7, -10, 7], [9, 12, 7 + 2], "rune")
cube("haste_cima", [7, 12, 7], [9, 24, 9], "wrap")
for i, y in enumerate((-8, -2, 4, 10, 16, 22)):          # faixas de pano enroladas
    cube(f"faixa{i}", [6.6, y, 6.6], [9.4, y + 1.6, 9.4], "wrap" if i % 2 else "bone")
# ponta (garras + cristal)
cube("garra", [6.4, -12, 6.4], [9.6, -9.5, 9.6], "bone")
cube("cristal1", [7.2, -14, 7.2], [8.8, -12, 8.8], "crystal")
cube("cristal2", [7.7, -16, 7.7], [8.3, -14, 8.3], "crystal")
# cabeça: colar, orbe e anel de ossos
cube("colar", [6, 24, 6], [10, 26, 10], "bone")
cube("orbe", [5.5, 26, 5.5], [10.5, 31, 10.5], "glow")
cube("anel_esq", [4, 26.5, 7], [5.5, 30.5, 9], "bone")
cube("anel_dir", [10.5, 26.5, 7], [12, 30.5, 9], "bone")
cube("anel_topo", [6, 31, 7], [10, 32, 9], "bone")
cube("anel_tl", [4.5, 30.5, 7], [6, 32, 9], "bone")
cube("anel_tr", [10, 30.5, 7], [11.5, 32, 9], "bone")
cube("anel_bl", [4.5, 25, 7], [6, 26.5, 9], "bone")
cube("anel_br", [10, 25, 7], [11.5, 26.5, 9], "bone")
# panos rasgados pendurados
cube("pano_esq", [5.4, 9, 7.3], [6.6, 23, 8.7], "cloth")
cube("pano_dir", [9.4, 14, 7.5], [10.4, 23, 8.5], "cloth")
cube("pano_tras", [7.4, 8, 9], [8.8, 22, 9.8], "cloth")
# correntes com caveiras
cube("corrente1", [9.8, 15, 7.9], [10.2, 24, 8.1], "chain")
cube("caveira1", [9.3, 12.4, 6.75], [11.7, 14.8, 9.25], "bone", front="skull")
cube("corrente2", [5.8, 19, 7.9], [6.2, 24, 8.1], "chain")
cube("caveira2", [4.8, 16.5, 6.75], [7.2, 18.9, 9.25], "bone", front="skull")
cube("corrente3", [9.8, 4, 7.9], [10.2, 10, 8.1], "chain")
cube("caveira3", [9.3, 1.6, 6.75], [11.7, 4, 9.25], "bone", front="skull")

for e in els:
    for v in e["from"] + e["to"]:
        pass
    assert all(-16 <= v <= 32 for v in e["from"] + e["to"]), e["name"]

model = {
    "credit": "Cajado Necromante - gerado por gen_staff.py",
    "texture_size": [32, 32],
    "textures": {"0": "classselector:item/necro_staff", "particle": "classselector:item/necro_staff"},
    "elements": els,
    "gui_light": "side",
    "display": {
        # Cajado em pé, levemente inclinado para frente, segurado mais perto da base.
        "thirdperson_righthand": {"rotation": [75, 0, 0], "translation": [0, 0, 3.5], "scale": [0.65, 0.65, 0.65]},
        "thirdperson_lefthand":  {"rotation": [75, 0, 0], "translation": [0, 0, 3.5], "scale": [0.65, 0.65, 0.65]},
        "firstperson_righthand": {"rotation": [0, -90, 20], "translation": [1.13, 4.5, 1.13], "scale": [0.6, 0.6, 0.6]},
        "firstperson_lefthand":  {"rotation": [0, 90, -20], "translation": [1.13, 4.5, 1.13], "scale": [0.6, 0.6, 0.6]},
        "gui":    {"rotation": [0, 0, -35], "translation": [0, 0, 0], "scale": [0.33, 0.33, 0.33]},
        "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.25, 0.25, 0.25]},
        "fixed":  {"rotation": [0, 0, -35], "translation": [0, 0, 0], "scale": [0.33, 0.33, 0.33]},
    },
}
os.makedirs(os.path.join(RES, "models/item"), exist_ok=True)
with open(os.path.join(RES, "models/item/necro_staff.json"), "w", encoding="utf-8") as f:
    json.dump(model, f, indent=2)
print("ok:", len(els), "cubos")

# ---------- preview rápido (frente) ----------
S = 10
pv = Image.new("RGBA", (24 * S, 50 * S), (14, 8, 22, 255))
for e in els:
    t = [k for k, v in TILES.items() if uv(k) == e["faces"]["east"]["uv"]][0]
    tx, ty = TILES[t]
    col = img.getpixel((tx * 8 + 3, ty * 8 + 3))
    x0, x1 = e["from"][0] - 2, e["to"][0] - 2
    y0, y1 = 32 - e["to"][1], 32 - e["from"][1]
    for x in range(int(x0 * S), int(x1 * S)):
        for y in range(int(y0 * S), int(y1 * S)):
            pv.putpixel((x + 0, y), col)
pv.save("/home/claude/preview_staff.png")
